package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.timetable.utils.TimeUtils;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TimetableSql timetableSql;
    private int selTime = -1;

    private TextView tv_show;
    private GridView gv_show;
    private TimetableBean bean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        timetableSql = new TimetableSql(this);
        if (timetableSql.queryToBean() == null || timetableSql.queryToBean().size() == 0) {
            startActivity(new Intent(MainActivity.this, SetTimeActivity.class));
            finish();
        }

    }

    private void initList() {
        List<TimetableBean> infoList = timetableSql.queryToBean();
        if (selTime == -1) {
            selTime = TimeUtils.countTwoDayWeek(this);
            if (selTime == -1) {
                selTime = 1;
            } else if (selTime == 0) {
                selTime = 1;
            }
        }
        try {
            bean = infoList.get(selTime - 1);
        } catch (Exception e) {
            selTime = 1;
            bean = infoList.get(0);
        }
        tv_show = (TextView) findViewById(R.id.tv_show);
        gv_show = (GridView) findViewById(R.id.gv_show);
        tv_show.setText("第" + selTime + "周" + "      今天" + TimeUtils.getCurrentWeek());

        List<String> datas = bean.getListData();


        tv_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listDialog();
            }
        });


        TimeTableAdapter adapter = new TimeTableAdapter(datas, this);
        gv_show.setAdapter(adapter);
        gv_show.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int number = position / 8;//从第几节开始循环
                if (number == 0) {
                    return;
                }

                for (int i = number; i < 7; i++) {
                    if (position > 8 * i && position < 16 * i) {
                        updataDialog(view, i, position);
                        return;
                    }
                }
            }
        });
    }


    //type:0"直接修改",1 "修改单周",2 "修改双周"
    public void alert_edit(final View view, final int jie, final int position, final int type) {
        final int zhou = position % 8;

        final EditText et_title = new EditText(this);
        et_title.setHint("请输入课程");
        final EditText et_jiaoshi = new EditText(this);
        et_jiaoshi.setHint("请输入教室");
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.addView(et_title);
        linearLayout.addView(et_jiaoshi);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请输入周" + zhou + "第" + jie + "节的课程");
        if (type == 1) {
            builder.setTitle("请输入所有单周周" + zhou + "第" + jie + "节的课程");
        } else if (type == 2) {
            builder.setTitle("请输入所有双周周" + zhou + "第" + jie + "节的课程");
        }
        builder.setView(linearLayout);

        builder.setNeutralButton("取消",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        builder.setNegativeButton("确定",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String val = et_title.getText().toString() + "\n"
                                + et_jiaoshi.getText().toString();
                        if (type == 0) {
                            bean.setCourseData(zhou, jie, val);
                            timetableSql.update(bean);
                        } else if (type == 1) {
                            List<TimetableBean> infoList = timetableSql.queryToBean();
                            int danOrShang = 1;
                            for (int i = 0; i < infoList.size(); i++) {
                                if ((i + 1) % 2 == danOrShang) {
                                    TimetableBean bean = infoList.get(i);
                                    bean.setCourseData(zhou, jie, val);
                                    timetableSql.update(bean);
                                }
                            }
                        } else {
                            List<TimetableBean> infoList = timetableSql.queryToBean();
                            int danOrShang = 0;
                            for (int i = 0; i < infoList.size(); i++) {
                                if ((i + 1) % 2 == danOrShang) {
                                    TimetableBean bean = infoList.get(i);
                                    bean.setCourseData(zhou, jie, val);
                                    timetableSql.update(bean);
                                }
                            }
                        }
                        initList();
                        dialog.cancel();
                    }
                });
        builder.create().show();
    }


    /**
     * 修改列表对话框
     */
    private void updataDialog(final View view, final int jie, final int position) {
        final String[] items = new String[]{"直接修改", "修改单周", "修改双周"};
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("选择修改方式");
        builder.setItems(items, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                alert_edit(view, jie, position, arg1);
            }
        });
        builder.create().show();
    }

    /**
     * 列表对话框
     */
    private void listDialog() {
        List<TimetableBean> infoList = timetableSql.queryToBean();
        final String[] items = new String[infoList.size()];
        for (int i = 0; i < infoList.size(); i++) {
            items[i] = "第" + (i + 1) + "周";
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("选择查看第几周课程表");
        builder.setItems(items, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                // TODO Auto-generated method stub
                selTime = arg1 + 1;
                initList();
            }
        });
        builder.create().show();

    }


    public void delTimeTable(View view) {
        List<TimetableBean> infoList = timetableSql.queryToBean();
        for (TimetableBean bean : infoList) {
            TimetableBean bean1 = new TimetableBean();
            bean1.setId(bean.getId());
            timetableSql.update(bean1);
        }
        initList();
    }


    @Override
    protected void onResume() {
        super.onResume();
        initList();
    }
}
