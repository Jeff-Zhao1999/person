package com.example.timetable;


import java.util.ArrayList;
import java.util.List;

public class TimetableBean {
    private int id;
    private String course1;//每周的第一节课，使用“!@#”隔开
    private String course2;//每周的第二节课，使用“!@#”隔开
    private String course3;//每周的第三节课，使用“!@#”隔开
    private String course4;//每周的第四节课，使用“!@#”隔开
    private String course5;//每周的第五节课，使用“!@#”隔开
    private String course6;//每周的第六节课，使用“!@#”隔开

    public TimetableBean() {
        course1 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
        course2 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
        course3 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
        course4 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
        course5 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
        course6 = TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT + TimetableSql.CUT_INIT + TimetableSql.CUT_INIT +
                TimetableSql.CUT_INIT;
    }

    public List<String> getListData() {
        List<String> datas = new ArrayList<>();
        datas.add("");
        datas.add("一");
        datas.add("二");
        datas.add("三");
        datas.add("四");
        datas.add("五");
        datas.add("六");
        datas.add("七");
        datas.add("1\n\n2");
        String[] c1 = course1.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c1[i]);
        }
        datas.add("3\n\n4");
        String[] c2 = course2.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c2[i]);
        }
        datas.add("5\n\n6");
        String[] c3 = course3.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c3[i]);
        }
        datas.add("7\n\n8");
        String[] c4 = course4.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c4[i]);
        }
        datas.add("9\n\n10");
        String[] c5 = course5.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c5[i]);
        }
        datas.add("11\n\n12");
        String[] c6 = course6.split(TimetableSql.CUT);
        for (int i = 0; i < 7; i++) {
            datas.add(c6[i]);
        }
        return datas;
    }

    /**
     * 修改课程表
     * @param jie 修改第几节的的数据
     * @param data
     * @return
     */
    /**
     * 修改课程表
     *
     * @param zhou 修改周几的的数据
     * @param jie  修改第几节的的数据
     * @param data 需要修改的数据
     * @return
     */
    public void setCourseData(int zhou, int jie, String data) {
        //一个周所有课的集合
        String[] allDatas = new String[]{course1, course2, course3, course4, course5, course6};
        //第几（jie）节课的集合（比如第五节课的集合就包含了周一到周日中第五节的集合）
        String[] jieDatas = allDatas[jie - 1].split(TimetableSql.CUT);
        //修改第几周第几节的数据
        jieDatas[zhou - 1] = data;
        allDatas[jie - 1] = "";
        for (String jieData : jieDatas) {
            allDatas[jie - 1] += jieData + TimetableSql.CUT;
        }
        switch (jie) {
            case 1:
                course1 = allDatas[jie - 1];
                break;
            case 2:
                course2 = allDatas[jie - 1];
                break;
            case 3:
                course3 = allDatas[jie - 1];
                break;
            case 4:
                course4 = allDatas[jie - 1];
                break;
            case 5:
                course5 = allDatas[jie - 1];
                break;
            case 6:
                course6 = allDatas[jie - 1];
                break;
        }
    }


    public String getCourse1() {
        return course1;
    }

    public void setCourse1(String course1) {
        this.course1 = course1;
    }

    public String getCourse2() {
        return course2;
    }

    public void setCourse2(String course2) {
        this.course2 = course2;
    }

    public String getCourse3() {
        return course3;
    }

    public void setCourse3(String course3) {
        this.course3 = course3;
    }

    public String getCourse4() {
        return course4;
    }

    public void setCourse4(String course4) {
        this.course4 = course4;
    }

    public String getCourse5() {
        return course5;
    }

    public void setCourse5(String course5) {
        this.course5 = course5;
    }

    public String getCourse6() {
        return course6;
    }

    public void setCourse6(String course6) {
        this.course6 = course6;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
