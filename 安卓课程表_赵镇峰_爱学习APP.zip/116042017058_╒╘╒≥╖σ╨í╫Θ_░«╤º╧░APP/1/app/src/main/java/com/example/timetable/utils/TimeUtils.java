package com.example.timetable.utils;

import android.content.Context;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class TimeUtils {


    /**
     * 获取当前周
     * @return
     */
    public static String getCurrentWeek() {
        long time = System.currentTimeMillis();
        Date date = new Date(time);
       /* SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒 EEEE");
        Log.e("time","time1="+format.format(date));
        format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Log.e("time","time2="+format.format(date));
        format=new SimpleDateFormat("yyyy/MM/dd");
        Log.e("time","time3="+format.format(date));
        format=new SimpleDateFormat("HH:mm:ss");
        Log.e("time","time4="+format.format(date));
        format=new SimpleDateFormat("EEEE");
        Log.e("time","time5="+format.format(date));*/
        SimpleDateFormat format = new SimpleDateFormat("E");
        Log.e("time", "time6=" + format.format(date));
        return format.format(date);
    }

    /**
     * 获取当前日期到起始周具体日期的周数差
     *
     * @return
     */
    public static Integer countTwoDayWeek(Context context) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date_start = null;
        Date date_end = null;
        try {
            Calendar calendar = Calendar.getInstance();
            //获取系统的日期
            //年
            int year = calendar.get(Calendar.YEAR);
            //月
            int month = calendar.get(Calendar.MONTH) + 1;
            //日
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            date_start = sdf.parse(year + "" + "-" + month + "-" + day);
            date_end = sdf.parse(SharedprefencesUtils.read(context));
        } catch (java.text.ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return -1;
        }
        return countTwoDayWeek(date_end, date_start);

    }

    /**
     * 获取两个日期的周数差
     *
     * @return
     */

    public static Integer countTwoDayWeek(Date startDate, Date endDate) {
        Date start = (Date) startDate;
        Date end = (Date) endDate;
        Calendar cal = Calendar.getInstance();
        cal.setTime(start);
        long time1 = cal.getTimeInMillis();
        cal.setTime(end);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        Double days = Double.parseDouble(String.valueOf(between_days));
        if ((days / 7) > 0 && (days / 7) <= 1) {
            //不满一周的按一周算
            return 1;
        } else if (days / 7 > 1) {
            int day = days.intValue();
            if (day % 7 > 0) {
                return day / 7 + 1;
            } else {
                return day / 7;
            }
        } else if ((days / 7) == 0) {
            return 0;
        } else {
            //负数返还null
            return -1;
        }

    }

}
