package com.example.timetable;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.timetable.utils.SharedprefencesUtils;

import java.util.Calendar;
import java.util.Locale;

//设置周期和起始日期
public class SetTimeActivity extends AppCompatActivity {
    private TextView tv_time;
    private EditText et_1;
    Calendar calendar = Calendar.getInstance(Locale.CHINA);
    private int years = 2020, monthOfYears, dayOfMonths;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_time);

        tv_time = (TextView) findViewById(R.id.tv_time);
        et_1 = (EditText) findViewById(R.id.et_1);

        tv_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(SetTimeActivity.this, 4, tv_time,
                        calendar);
            }
        });

        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(tv_time.getText().toString())) {
                    Toast.makeText(SetTimeActivity.this, "请选择起始日期",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(et_1.getText().toString())) {
                    Toast.makeText(SetTimeActivity.this, "请输入总周期",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                int index = Integer.valueOf(et_1.getText().toString());
                if (index <= 0) {
                    Toast.makeText(SetTimeActivity.this, "选择起始日期不能小于一",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                TimetableSql timetableSql = new TimetableSql(SetTimeActivity.this);
                for (int i = 0; i < index; i++) {
                    TimetableBean bean = new TimetableBean();
                    timetableSql.insert(bean);
                }
                SharedprefencesUtils.write(SetTimeActivity.this, years + "-"
                        + (monthOfYears + 1) + "-" + dayOfMonths);
                startActivity(new Intent(SetTimeActivity.this, MainActivity.class));
                finish();

            }
        });

    }


    /**
     * 日期选择
     */
    public void showDatePickerDialog(Activity activity, int themeResId,
                                     final TextView tv, Calendar calendar) {
        // 直接创建一个DatePickerDialog对话框实例，并将它显示出来
        new DatePickerDialog(activity, themeResId,
                new DatePickerDialog.OnDateSetListener() {
                    // 绑定监听器(How the parent is notified that the date is set.)
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        // 此处得到选择的时间，可以进行你想要的操作
                        tv.setText("您选择了：" + year + "年" + (monthOfYear + 1)
                                + "月" + dayOfMonth + "日");
                        years = year;
                        monthOfYears = monthOfYear;
                        dayOfMonths = dayOfMonth;
                    }
                }
                // 设置初始日期
                , years, monthOfYears, dayOfMonths).show();
    }
}
