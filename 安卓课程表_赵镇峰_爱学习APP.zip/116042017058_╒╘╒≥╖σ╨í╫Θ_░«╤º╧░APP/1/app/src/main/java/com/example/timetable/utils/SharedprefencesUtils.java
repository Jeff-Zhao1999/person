package com.example.timetable.utils;


import android.content.Context;
import android.content.SharedPreferences;

//起始周具体日期 数据保存读取
public class SharedprefencesUtils {

    public static void write(Context context, String time) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("time", Context.MODE_PRIVATE);/////////////////////
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("time", time);
        editor.apply();
    }

    public static String read(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("time", Context.MODE_PRIVATE);/////////////////////
        return sharedPreferences.getString("time", "");
    }

}
