package com.example.timetable;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class TimetableSql extends SQLiteOpenHelper {
    public static final String CUT = "!@#"; //每周的课，使用“!@#”隔开
    public static final String CUT_INIT = " " + CUT; //每周的课，使用“!@#”隔开
    public static final String TABLE_NAME = "info";//表名
    public static final String ID = "_id";//数据库ID
    public static final String COURSE1 = "course1";//每周的第一节课，使用“!@#”隔开
    public static final String COURSE2 = "course2";//每周的第二节课，使用“!@#”隔开
    public static final String COURSE3 = "course3";//每周的第三节课，使用“!@#”隔开
    public static final String COURSE4 = "course4";//每周的第四节课，使用“!@#”隔开
    public static final String COURSE5 = "course5";//每周的第五节课，使用“!@#”隔开
    public static final String COURSE6 = "course6";//每周的第六节课，使用“!@#”隔开

    public TimetableSql(Context context) {
        //数据库名
        super(context, "timetable8", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql1 = "create table " + TABLE_NAME + " ( " + ID
                + " integer primary key AUTOINCREMENT, "
                + COURSE1 + " TEXT NOT NULL, "
                + COURSE2 + " TEXT NOT NULL, "
                + COURSE3 + " TEXT NOT NULL, "
                + COURSE4 + " TEXT NOT NULL, "
                + COURSE5 + " TEXT NOT NULL, "
                + COURSE6 + " TEXT NOT NULL )";
        db.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insert(TimetableBean bean) {
        SQLiteDatabase dbreader = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COURSE1, bean.getCourse1());
        cv.put(COURSE2, bean.getCourse2());
        cv.put(COURSE3, bean.getCourse3());
        cv.put(COURSE4, bean.getCourse4());
        cv.put(COURSE5, bean.getCourse5());
        cv.put(COURSE6, bean.getCourse6());
        long index = dbreader.insert(TABLE_NAME, null, cv);
    }

    public void delete(int id) {
        SQLiteDatabase dbreader = getWritableDatabase();
        long index = dbreader.delete(TABLE_NAME, ID + "=?", new String[]{id + ""});
    }

    public void update(TimetableBean bean) {
        SQLiteDatabase dbreader = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COURSE1, bean.getCourse1());
        cv.put(COURSE2, bean.getCourse2());
        cv.put(COURSE3, bean.getCourse3());
        cv.put(COURSE4, bean.getCourse4());
        cv.put(COURSE5, bean.getCourse5());
        cv.put(COURSE6, bean.getCourse6());
        dbreader.update(TABLE_NAME, cv, ID + "=?", new String[]{bean.getId() + ""});
    }


    public Cursor query() {
        try {
            SQLiteDatabase dbreader = getReadableDatabase();
            Cursor cursor = dbreader.query(TABLE_NAME, null, null, null, null,
                    null, null);
            return cursor;
        } catch (Exception e) {
            return null;
        }
    }

    public List<TimetableBean> queryToBean() {
        Cursor cursor = query();
        List<TimetableBean> infoList = new ArrayList<>();

        if (cursor == null) {
            return infoList;
        }
        while (cursor.moveToNext()) {
            //moveToNext()移动光标到下一行
            int id = cursor.getInt(cursor.getColumnIndex(ID));
            TimetableBean bean = new TimetableBean();
            bean.setId(id);
            bean.setCourse1(cursor.getString(cursor.getColumnIndex(COURSE1)));
            bean.setCourse2(cursor.getString(cursor.getColumnIndex(COURSE2)));
            bean.setCourse3(cursor.getString(cursor.getColumnIndex(COURSE3)));
            bean.setCourse4(cursor.getString(cursor.getColumnIndex(COURSE4)));
            bean.setCourse5(cursor.getString(cursor.getColumnIndex(COURSE5)));
            bean.setCourse6(cursor.getString(cursor.getColumnIndex(COURSE6)));

            infoList.add(bean);
        }
        return infoList;
    }

}